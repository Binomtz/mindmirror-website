// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB0dqUPLcDD8qEZRIV1XhJwpD0jFp-nteQ",
  authDomain: "mindmirror-2c816.firebaseapp.com",
  projectId: "mindmirror-2c816",
  storageBucket: "mindmirror-2c816.appspot.com",
  messagingSenderId: "1007950866124",
  appId: "1:1007950866124:web:18e356077d59c7a9330469",
  measurementId: "G-RQ0KVFF4NS"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);